__version__ = "1.0.0"

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle, Ellipse, Line, Triangle
from kivy.uix.widget import Widget
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.metrics import dp
import random, math, time

Window.fullscreen = 'auto'
Window.clearcolor = (0.012, 0.018, 0.055, 1)

class NeonGame(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.score = 0
        self.health = 100
        self.level = 1
        self.player_x = 0.5
        self.player_y = 0.19
        self.bullets = []
        self.enemies = []
        self.enemy_bullets = []
        self.particles = []
        self.stars = [[random.random(), random.random(), random.uniform(.15,.55)] for _ in range(90)]
        self.spawn = 0
        self.shot = 0
        self.started = False
        self.game_over = False
        self.touch_target = None
        self.hud = Label(text="", font_size='15sp', bold=True,
                         color=(.85,.96,1,1), size_hint=(1,None),
                         height=dp(42), pos_hint={'top':1})
        self.add_widget(self.hud)
        self.overlay = Label(text="", markup=True, halign='center',
                             valign='middle', font_size='22sp',
                             size_hint=(.9,.35), pos_hint={'center_x':.5,'center_y':.52})
        self.add_widget(self.overlay)
        self.restart_btn = Button(text="PLAY AGAIN", size_hint=(.56,.09),
                                  pos_hint={'center_x':.5,'center_y':.36},
                                  background_normal='', background_color=(.35,.04,.75,1),
                                  color=(1,1,1,1), bold=True, opacity=0, disabled=True)
        self.restart_btn.bind(on_release=self.reset)
        self.add_widget(self.restart_btn)
        Clock.schedule_interval(self.update, 1/60)
        self.reset()

    def reset(self, *args):
        self.score=0; self.health=100; self.level=1
        self.player_x=.5; self.player_y=.19
        self.bullets=[]; self.enemies=[]; self.enemy_bullets=[]; self.particles=[]
        self.spawn=0; self.shot=0
        self.game_over=False; self.started=True
        self.overlay.text=""
        self.restart_btn.opacity=0; self.restart_btn.disabled=True

    def burst(self, x, y, color=(.7,.1,1,1)):
        for _ in range(16):
            a=random.random()*math.tau; s=random.uniform(45,190)
            self.particles.append([x,y,math.cos(a)*s,math.sin(a)*s,random.uniform(.25,.65),color])

    def on_touch_down(self, touch):
        if self.game_over:
            return super().on_touch_down(touch)
        self.touch_target=(touch.x/self.width, touch.y/self.height)
        return True

    def on_touch_move(self, touch):
        self.touch_target=(touch.x/self.width, touch.y/self.height)
        return True

    def on_touch_up(self, touch):
        self.touch_target=None
        return True

    def update(self, dt):
        if self.width <= 0 or self.height <= 0: return
        w,h=self.width,self.height
        dt=min(dt,.04)
        self.canvas.clear()
        with self.canvas:
            Color(.012,.018,.055,1); Rectangle(pos=self.pos,size=self.size)

            # Starfield
            for s in self.stars:
                s[1]-=s[2]*dt
                if s[1]<0: s[1]=1; s[0]=random.random()
                Color(.05,.65,1,.45)
                Ellipse(pos=(s[0]*w,s[1]*h),size=(dp(2),dp(2)))

            # Subtle grid lines
            Color(.025,.12,.22,.45)
            for i in range(1,8):
                y=h*i/8
                Line(points=[0,y,w,y],width=1)

            if not self.game_over:
                if self.touch_target:
                    tx,ty=self.touch_target
                    self.player_x += (max(.06,min(.94,tx))-self.player_x)*min(1,dt*11)
                    self.player_y += (max(.12,min(.76,ty))-self.player_y)*min(1,dt*11)

                self.level=1+self.score//120
                self.spawn+=dt; self.shot+=dt
                if self.shot>.23:
                    self.bullets.append([self.player_x*w,self.player_y*h+dp(24)])
                    self.shot=0
                if self.spawn>max(.34,1.05-self.level*.055):
                    self.enemies.append([random.uniform(.08,.92)*w,h+dp(30),random.uniform(125,190)+self.level*9,0])
                    self.spawn=0

                # Player shots
                for b in self.bullets[:]:
                    b[1]+=dt*650
                    if b[1]>h: self.bullets.remove(b); continue
                    Color(0,.85,1,1); Line(points=[b[0],b[1]-dp(10),b[0],b[1]+dp(10)],width=dp(3))

                # Enemies and collisions
                for e in self.enemies[:]:
                    e[1]-=e[2]*dt; e[3]+=dt
                    x,y=e[0],e[1]
                    Color(1,.08,.48,1)
                    Triangle(points=[x,y-dp(19),x-dp(23),y+dp(16),x,y+dp(7)])
                    Triangle(points=[x,y-dp(19),x+dp(23),y+dp(16),x,y+dp(7)])
                    Color(1,.75,.95,1); Ellipse(pos=(x-dp(4),y-dp(3)),size=(dp(8),dp(8)))
                    if e[3]>1.8:
                        self.enemy_bullets.append([x,y-dp(12)])
                        e[3]=0
                    if y<self.player_y*h+dp(25) and y>self.player_y*h-dp(30) and abs(x-self.player_x*w)<dp(30):
                        self.burst(x,y,(1,.1,.2,1)); self.enemies.remove(e); self.health-=20; continue
                    if y<0:
                        self.enemies.remove(e); self.health-=10; continue
                    hit=None
                    for b in self.bullets:
                        if math.hypot(x-b[0],y-b[1])<dp(27):
                            hit=b; break
                    if hit:
                        if e in self.enemies:self.enemies.remove(e)
                        if hit in self.bullets:self.bullets.remove(hit)
                        self.score+=10; self.burst(x,y)
                # Enemy projectiles
                for b in self.enemy_bullets[:]:
                    b[1]-=dt*330
                    Color(1,.12,.25,1); Ellipse(pos=(b[0]-dp(5),b[1]-dp(5)),size=(dp(10),dp(10)))
                    if math.hypot(b[0]-self.player_x*w,b[1]-self.player_y*h)<dp(26):
                        self.enemy_bullets.remove(b); self.health-=15; self.burst(self.player_x*w,self.player_y*h,(1,.1,.2,1)); continue
                    if b[1]<0:self.enemy_bullets.remove(b)

                # Particles
                for p in self.particles[:]:
                    p[0]+=p[2]*dt; p[1]+=p[3]*dt; p[4]-=dt
                    Color(*p[5]); Ellipse(pos=(p[0]-dp(2),p[1]-dp(2)),size=(dp(4),dp(4)))
                    if p[4]<=0:self.particles.remove(p)

                # Player ship
                px,py=self.player_x*w,self.player_y*h
                Color(.0,.78,1,1)
                Triangle(points=[px,py+dp(29),px-dp(25),py-dp(22),px,py-dp(10)])
                Triangle(points=[px,py+dp(29),px+dp(25),py-dp(22),px,py-dp(10)])
                Color(.8,.95,1,1); Line(points=[px,py+dp(29),px-dp(25),py-dp(22),px,py-dp(10),px+dp(25),py-dp(22),px,py+dp(29)],width=dp(1.5))
                Color(.65,.05,1,1); Ellipse(pos=(px-dp(6),py-dp(4)),size=(dp(12),dp(15)))
                Color(1,.15,.8,1); Triangle(points=[px-dp(8),py-dp(18),px,py-dp(40)-random.randint(0,dp(8)),px+dp(8),py-dp(18)])

                # HUD
                Color(0,.7,1,.9); Line(points=[dp(18),h-dp(72),w-dp(18),h-dp(72)],width=dp(1))
                Color(.2,.9,1,1); Rectangle(pos=(dp(18),h-dp(55)),size=(w-dp(36),dp(7)))
                Color(.05,.08,.18,1); Rectangle(pos=(dp(18),h-dp(55)),size=((w-dp(36))*(1-max(0,self.health)/100),dp(7)))
                self.hud.text=f"NEON STRIKE     SCORE {self.score}     LV {self.level}     HULL {max(0,self.health)}%"
                if self.health<=0:
                    self.game_over=True
            else:
                for p in self.particles[:]:
                    p[0]+=p[2]*dt; p[1]+=p[3]*dt; p[4]-=dt
                    Color(*p[5]); Ellipse(pos=(p[0]-dp(2),p[1]-dp(2)),size=(dp(4),dp(4)))
                    if p[4]<=0:self.particles.remove(p)

        if self.game_over:
            self.hud.text=f"NEON STRIKE     FINAL SCORE {self.score}"
            self.overlay.text=f"[color=ff3978]MISSION FAILED[/color]\n[color=00ddff]FINAL SCORE: {self.score}[/color]"
            self.restart_btn.opacity=1; self.restart_btn.disabled=False

class NeonApp(App):
    def build(self):
        self.title="NEON STRIKE"
        return NeonGame()

if __name__ == "__main__":
    NeonApp().run()
