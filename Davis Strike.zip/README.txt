# NEON STRIKE — Android APK project

This is a Kivy/Buildozer Android project prepared for a cloud build.

## Files
- `main.py`: Android-compatible Kivy arcade game.
- `buildozer.spec`: Android package settings and app icon.
- `icon.png`: NEON STRIKE launcher icon.
- `.github/workflows/build-apk.yml`: manual GitHub Actions APK build.

## Build from an Android phone
1. Create a GitHub account and a new repository named `neon-strike`.
2. Upload the contents of this folder to the repository, keeping `.github/workflows/build-apk.yml` at that exact path.
3. In the repository, open **Actions**.
4. Select **Build NEON STRIKE APK** and tap **Run workflow**.
5. Wait for the workflow to finish successfully.
6. Open the completed run, scroll to **Artifacts**, and download `NEON-STRIKE-APK`.
7. Extract the downloaded ZIP and install the APK. Android may ask you to allow installs from your browser or file manager.

The cloud build can take several minutes, especially on its first run. Keep the repository public if using a free GitHub account and you want the simplest setup, or check the current GitHub Actions minutes/permissions for private repositories.

This project uses Kivy and Buildozer. It is not the original Pygame script; it is a Kivy port designed for Android packaging.
